gutautocorr.m - given a vector and a number of
  principal components to remove, gives you the
  residual autocorrelation according to their paper.
gsgutsims.m - does relevant monte carlo simulations
   to give a minimum # of points-in-a-row for within
   subjects comparisons
gsgutsimsbetween.m - same for between subjects
diffwavgraph.m - shows the mean of waveforms for
  two conditions with periods of significant differences
  highlighted
grpdiffwavgraph.m - same thing for between subjects
